class HomeController < ApplicationController
  def index
    @users = User.includes(:quotes).where(status: "Active").take(5)
  end
end

