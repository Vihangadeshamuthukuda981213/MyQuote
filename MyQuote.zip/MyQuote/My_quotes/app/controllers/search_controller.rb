class SearchController < ApplicationController
  # The index action handles the search functionality
  def index
    # Retrieve the search query from the params
    quote_query = params[:quote_query]
    
    # Check if the search query is present
    if quote_query.present?
      # If the search query is present, find quotes whose quo_text contains the search query
      @quotes = Quote.where("quo_text LIKE ?", "%#{quote_query}%")
    end
  end
end
