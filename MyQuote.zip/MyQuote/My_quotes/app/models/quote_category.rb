
class QuoteCategory < ApplicationRecord
  belongs_to :quote
  belongs_to :category
  validates :cat_qty, presence: true
  validates :category_id, presence: true
end
