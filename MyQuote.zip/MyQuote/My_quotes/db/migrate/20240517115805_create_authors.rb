class CreateAuthors < ActiveRecord::Migration[7.0]
  def change
    create_table :authors do |t|
      t.string :author_firstname, null:false
      t.string :author_lastname, null:false
      t.date :birth_year, null:false
      t.text :biography, null:false
      t.date :deth_year, null:false

      t.timestamps
    end
  end
end
